
 This is yabasic.

A simple Basic interpreter for Unix and Windows.

Yabasic implements the most common and simple elements of the basic
language. It comes with goto/gosub, with various loops, with user
defined subroutines and Libraries. Yabasic does simple graphics and
printing. Yabasic runs under Unix and Windows, it is small, open
source and free.

Yabasic associates itself with the File-Extension '.yab' and adds
suitable entries to its context-menu.

install   : Start setup.exe
remove    : As usual via control panel
customize : Registry under HKEY_LOCAL_MACHINE/SOFTWARE/yabasic

A full description of the syntax of yabasic can be found 
in the file:           yabasic.htm or on www.yabasic.de
Or have a look at:     demo.yab

Please send any comments and bug reports to:   mail@yabasic.de
The Version number can be found in:            yabver.txt

Happy Basic-programming !
